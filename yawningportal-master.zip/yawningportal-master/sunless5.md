# The Sunless Citadel: Epilogue

Sharwyn's eyes flicker open. "Where am I?" she asks. Remy turns on the charm. He explains what has happened. But Sharwyn has no memory of events. In fact she has no memories at all. Claude uses his identify spell to see if there is any magical effect preventing her from remembering, but finds none.

Meanwhile Dioica decides what to do with Belak. Clearly he cannot be trusted and the party has no way to keep a druid of his power contained. She decides to execute him and let her druid circle deal with his body as they see fit. Erky casts a preservation spell on Belak, should the druids want to question him later. The party then make their way back to Oakhurst to return Sharwyn to her mother.

Back in Oakhurst they divide up their loot. Bobolink insists on selling all of the gems and artefacts and arranges a messenger to send his share back to the orphanage in Waterdeep. On attempting to sell Durgeddin's scroll to the blacksmith, they learn the tale of Durgeddin the master smith who made blades of surpassing quality and power. Nobody knows the location of the stronghold, Khundrukar except that it is somewhere in the mountains to the north. He also notes that Ocardo's blade, Shatterspike, was crafted by Durgeddin. Ocardo asks Remy to use his contacts in Waterdeep to find out more about Durgeddin and his stronghold.

Dioica takes Belak's body to her druid circle. They thank her for bringing the monster to justice, and warn her of a renewed gathering of orcs in the mountains to the north that threaten to upset the natural balance. Claude and Badger have other business to attend to and arrange to catch up with the rest of the party later.

Remy's fence in Waterdeep finds him a buyer for the book of dragon lore. He also tells Remy of Baron Althon, a noble from the small mining town of Blasingdell and his interest in the legend of Durgeddin. Remy spends some time and money acquiring a pair of shiny trousers.
