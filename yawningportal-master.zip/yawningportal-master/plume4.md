# White Plume Mountain: Epilogue

With the genies defeated, you collect your treasure and make your way back to Dead Gnoll's Eye Socket. There, you find that your horses have gone. You find tracks leading back in the direction of Plumfall. You are tired from your exertions, but you resolve to drag your treasure back to the village on foot.

In the village, Remy quickly tracks down the horse thieves and recovers your horses. However, instead of turning the perpetrators in to the local authorities, he decides take them on as his own contacts. You quickly arrange travel back to Neverwinter and consider what to do with the magic weapons you have recovered.

Wave and Whelm are reluctant to go back to their previous owners as they don't want to be locked back in display cases. Instead you decide to hunt around for a pair of hirelings with the necessary attributes to wield these remarkable weapons. After some searching, you find such a pair: ex entertainers, Chas, a lawful good dwarven cleric of Moradin, and; Dave, a human fighter and true neutral follower of Melora.

You also attempt to buy additional magic items and weapons. While you are carrying out your search, Poon Tang creates a false identity known as Lady Wayne. Along with Ocardo, they spend their evenings hunting down Neverwinter's muggers and harvesting their souls to feed Blackrazor's insatiable appetite.

Your magic item searches turn up a _+2 scimitar_ for Badger, a _+2 bow_ for Poon Tang, _gauntlets of ogre power_ for Ocardo, and a rather pricey _+2 short bow_ for Remy.

During this time you catch news of a plot, near the village of Daggerford on the Sword Coast, by the infamous _Red Wizards of Thay_ to overthrow and take control of the North. A group of heroes have managed to thwart the attack and have captured a teleportation circle. You decide to travel to Daggerford to investigate.
